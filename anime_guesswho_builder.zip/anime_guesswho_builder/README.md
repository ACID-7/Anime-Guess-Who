# Anime Guess Who builder pack

This pack is for generating a **5000+ row anime / character dataset** for a Guess Who-style game.

## What is included

- `anime_seed_list.csv` - 205 curated anime targets across action, fantasy, sports, romance, sci-fi, classics, and slice-of-life.
- `anime_seed_list.json` - same seed list in JSON.
- `generate_dataset.py` - pulls anime IDs, character IDs, anime images, and character images from Jikan and writes CSV / JSON / XLSX outputs.
- `anime_guesswho_seed_workbook.xlsx` - seed list and output schema in spreadsheet form.
- `schema.json` - column schema for the three core tables.

## Output tables

### 1) `animes.csv`
One row per anime.

### 2) `characters.csv`
One row per unique character.

### 3) `anime_character_links.csv`
Many-to-many link table so one character can appear in multiple related shows or seasons.

## Recommended game fields

Use these immediately in your game:

- anime UID
- anime title
- anime image URL
- character UID
- character name
- character image URL
- role (`Main` / `Supporting`)
- anime-character link table

If you want trait questions later, add a second pass for custom attributes like hair color, glasses, weapon, role archetype, powers, or school/team.

## Quick start

```bash
python generate_dataset.py --input anime_seed_list.csv --outdir ./output
```

Optional:

```bash
python generate_dataset.py --input anime_seed_list.csv --outdir ./output --main-only
python generate_dataset.py --input anime_seed_list.csv --outdir ./output --pause-seconds 2.1
```

## Notes

- The builder stores **image URLs**, not downloaded image files, so your output stays small.
- The default seed list is sized so a full run should comfortably exceed **5000 anime-character links**.
- If you want local image files too, add your own download step after generation and make sure you have rights to use those images.
