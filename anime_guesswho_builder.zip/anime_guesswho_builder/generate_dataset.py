from __future__ import annotations
import argparse
import csv
import difflib
import json
import os
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

API_ROOT = 'https://api.jikan.moe/v4'
USER_AGENT = 'anime-guesswho-builder/1.0'


def normalize(s: Optional[str]) -> str:
    return ''.join(ch.lower() for ch in (s or '') if ch.isalnum())


def slurp_json(url: str, pause_seconds: float = 2.1, retries: int = 4) -> dict:
    last_err = None
    for attempt in range(retries):
        try:
            req = Request(url, headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'})
            with urlopen(req, timeout=60) as resp:
                payload = json.loads(resp.read().decode('utf-8'))
            time.sleep(pause_seconds)
            return payload
        except HTTPError as e:
            last_err = e
            if e.code == 429:
                wait_s = max(5, 10 * (attempt + 1))
                print(f'[rate-limit] {url} -> sleeping {wait_s}s')
                time.sleep(wait_s)
                continue
            if 500 <= e.code < 600:
                wait_s = 5 * (attempt + 1)
                print(f'[server-error] {url} -> sleeping {wait_s}s')
                time.sleep(wait_s)
                continue
            raise
        except URLError as e:
            last_err = e
            wait_s = 5 * (attempt + 1)
            print(f'[network-error] {url} -> sleeping {wait_s}s')
            time.sleep(wait_s)
    raise RuntimeError(f'Failed to fetch {url}: {last_err}')


def title_candidates(item: dict) -> List[str]:
    vals = [
        item.get('title'),
        item.get('title_english'),
        item.get('title_japanese'),
    ]
    for t in item.get('titles', []) or []:
        vals.append(t.get('title'))
    vals.extend(item.get('title_synonyms', []) or [])
    return [v for v in vals if v]


def score_match(query: str, item: dict) -> float:
    qn = normalize(query)
    best = 0.0
    for cand in title_candidates(item):
        cn = normalize(cand)
        if not cn:
            continue
        if cn == qn:
            best = max(best, 10.0)
        elif qn in cn or cn in qn:
            best = max(best, 8.0)
        else:
            best = max(best, difflib.SequenceMatcher(a=qn, b=cn).ratio() * 5.0)
    type_pref = item.get('type') or ''
    if type_pref == 'TV':
        best += 1.5
    elif type_pref in {'ONA', 'OVA'}:
        best += 0.5
    return best


def choose_best_match(query: str, items: List[dict]) -> Optional[dict]:
    if not items:
        return None
    scored = sorted(((score_match(query, x), x) for x in items), key=lambda t: t[0], reverse=True)
    if scored[0][0] < 2.0:
        return None
    return scored[0][1]


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def read_seed_csv(path: Path) -> List[dict]:
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def cache_get_json(cache_dir: Path, cache_key: str, url: str, pause_seconds: float) -> dict:
    ensure_dir(cache_dir)
    target = cache_dir / f'{cache_key}.json'
    if target.exists():
        return json.loads(target.read_text(encoding='utf-8'))
    payload = slurp_json(url, pause_seconds=pause_seconds)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return payload


def write_csv(path: Path, rows: List[dict], fieldnames: List[str]) -> None:
    with path.open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def maybe_make_xlsx(outdir: Path, anime_rows: List[dict], character_rows: List[dict], link_rows: List[dict]) -> None:
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
        from openpyxl.utils import get_column_letter
    except Exception as e:
        print(f'[warn] skipping xlsx export: {e}')
        return

    wb = Workbook()
    thin = Side(style='thin', color='D9E2F3')
    header_fill = PatternFill('solid', fgColor='1F4E78')
    header_font = Font(color='FFFFFF', bold=True)
    sub_fill = PatternFill('solid', fgColor='D9EAF7')

    def add_sheet(title: str, rows: List[dict]):
        ws = wb.create_sheet(title)
        if not rows:
            ws['A1'] = 'No rows'
            return
        headers = list(rows[0].keys())
        ws.append(headers)
        for c in ws[1]:
            c.font = header_font
            c.fill = header_fill
            c.border = Border(bottom=thin)
            c.alignment = Alignment(horizontal='center', vertical='center')
        for row in rows:
            ws.append([row.get(h, '') for h in headers])
        for row in ws.iter_rows(min_row=2):
            for c in row:
                c.alignment = Alignment(vertical='center', wrap_text=True)
        widths = {}
        for i, h in enumerate(headers, start=1):
            max_len = max(len(str(h)), *(len(str(r.get(h, ''))) for r in rows[:300]))
            widths[i] = min(max(14, max_len + 2), 44)
        for i, width in widths.items():
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.freeze_panes = 'A2'
        ws.sheet_view.showGridLines = False

    wb.remove(wb.active)
    add_sheet('Animes', anime_rows)
    add_sheet('Characters', character_rows)
    add_sheet('Anime_Character_Links', link_rows)
    summary = wb.create_sheet('Summary', 0)
    summary['A1'] = 'Anime Guess Who dataset build summary'
    summary['A1'].font = Font(size=14, bold=True)
    summary['A3'] = 'Anime rows'
    summary['B3'] = len(anime_rows)
    summary['A4'] = 'Character rows'
    summary['B4'] = len(character_rows)
    summary['A5'] = 'Anime-character links'
    summary['B5'] = len(link_rows)
    for cell in ['A3', 'A4', 'A5']:
        summary[cell].fill = sub_fill
        summary[cell].font = Font(bold=True)
    summary.column_dimensions['A'].width = 28
    summary.column_dimensions['B'].width = 12
    summary.sheet_view.showGridLines = False
    wb.save(outdir / 'anime_guesswho_dataset.xlsx')


def main() -> None:
    parser = argparse.ArgumentParser(description='Build anime + character dataset from Jikan for a Guess Who-style game.')
    parser.add_argument('--input', required=True, help='Path to anime seed CSV')
    parser.add_argument('--outdir', required=True, help='Output directory')
    parser.add_argument('--pause-seconds', type=float, default=2.1, help='Delay between API requests')
    parser.add_argument('--main-only', action='store_true', help='Keep only Main characters in the link table')
    args = parser.parse_args()

    seed_path = Path(args.input)
    outdir = Path(args.outdir)
    cache_dir = outdir / '.cache'
    ensure_dir(outdir)
    ensure_dir(cache_dir)

    seeds = read_seed_csv(seed_path)
    anime_rows: List[dict] = []
    character_rows: List[dict] = []
    link_rows: List[dict] = []
    failures: List[dict] = []

    character_map: Dict[str, str] = {}
    character_payloads: Dict[str, dict] = {}

    for anime_index, seed in enumerate(seeds, start=1):
        anime_uid = seed['anime_seed_id']
        query = seed['search_title']
        query_params = urlencode({'q': query, 'limit': 10})
        search_url = f'{API_ROOT}/anime?{query_params}'
        cache_key = f'search_{anime_uid}'
        try:
            search_payload = cache_get_json(cache_dir, cache_key, search_url, args.pause_seconds)
            search_items = search_payload.get('data', []) or []
            best = choose_best_match(query, search_items)
            if not best:
                failures.append({'anime_seed_id': anime_uid, 'search_title': query, 'stage': 'search_match', 'reason': 'no_good_match'})
                print(f'[skip] no good match for {query}')
                continue

            mal_id = best['mal_id']
            anime_rows.append({
                'anime_uid': anime_uid,
                'anime_mal_id': mal_id,
                'search_title': query,
                'resolved_title': best.get('title') or '',
                'title_english': best.get('title_english') or '',
                'title_japanese': best.get('title_japanese') or '',
                'type': best.get('type') or '',
                'status': best.get('status') or '',
                'episodes': best.get('episodes') or '',
                'year': best.get('year') or '',
                'score': best.get('score') or '',
                'rank': best.get('rank') or '',
                'popularity': best.get('popularity') or '',
                'members': best.get('members') or '',
                'favorites': best.get('favorites') or '',
                'genres_pipe': '|'.join(x.get('name', '') for x in (best.get('genres') or []) if x.get('name')),
                'themes_pipe': '|'.join(x.get('name', '') for x in (best.get('themes') or []) if x.get('name')),
                'demographics_pipe': '|'.join(x.get('name', '') for x in (best.get('demographics') or []) if x.get('name')),
                'anime_image_url': (((best.get('images') or {}).get('jpg') or {}).get('large_image_url') or ((best.get('images') or {}).get('jpg') or {}).get('image_url') or ''),
                'anime_url': best.get('url') or '',
                'source_api': 'Jikan v4'
            })

            char_url = f'{API_ROOT}/anime/{mal_id}/characters'
            char_payload = cache_get_json(cache_dir, f'characters_{anime_uid}', char_url, args.pause_seconds)
            char_items = char_payload.get('data', []) or []
            order = 0
            for item in char_items:
                role = item.get('role') or ''
                if args.main_only and role.lower() != 'main':
                    continue
                char = item.get('character') or {}
                char_mal_id = char.get('mal_id')
                if not char_mal_id:
                    continue
                order += 1
                key = str(char_mal_id)
                if key not in character_map:
                    character_uid = f'CHR{len(character_map) + 1:05d}'
                    character_map[key] = character_uid
                    row = {
                        'character_uid': character_uid,
                        'character_mal_id': char_mal_id,
                        'character_name': char.get('name') or '',
                        'character_name_kanji': char.get('name_kanji') or '',
                        'primary_image_url': (((char.get('images') or {}).get('jpg') or {}).get('image_url') or ''),
                        'character_url': char.get('url') or '',
                        'source_api': 'Jikan v4'
                    }
                    character_payloads[key] = row
                link_rows.append({
                    'link_uid': f'ACL{len(link_rows) + 1:07d}',
                    'anime_uid': anime_uid,
                    'character_uid': character_map[key],
                    'anime_mal_id': mal_id,
                    'character_mal_id': char_mal_id,
                    'role': role,
                    'order_in_anime': order
                })
            print(f'[ok] {anime_index}/{len(seeds)} {query} -> {best.get("title")} ({len(char_items)} characters returned)')
        except Exception as e:
            failures.append({'anime_seed_id': anime_uid, 'search_title': query, 'stage': 'fetch', 'reason': str(e)})
            print(f'[error] {query}: {e}')

    character_rows = sorted(character_payloads.values(), key=lambda r: (r['character_name'].lower(), r['character_uid']))
    anime_rows = sorted(anime_rows, key=lambda r: r['anime_uid'])

    write_csv(outdir / 'animes.csv', anime_rows, list(anime_rows[0].keys()) if anime_rows else [
        'anime_uid', 'anime_mal_id', 'search_title', 'resolved_title', 'title_english', 'title_japanese',
        'type', 'status', 'episodes', 'year', 'score', 'rank', 'popularity', 'members', 'favorites',
        'genres_pipe', 'themes_pipe', 'demographics_pipe', 'anime_image_url', 'anime_url', 'source_api'
    ])
    write_csv(outdir / 'characters.csv', character_rows, list(character_rows[0].keys()) if character_rows else [
        'character_uid', 'character_mal_id', 'character_name', 'character_name_kanji', 'primary_image_url', 'character_url', 'source_api'
    ])
    write_csv(outdir / 'anime_character_links.csv', link_rows, list(link_rows[0].keys()) if link_rows else [
        'link_uid', 'anime_uid', 'character_uid', 'anime_mal_id', 'character_mal_id', 'role', 'order_in_anime'
    ])
    write_csv(outdir / 'failures.csv', failures, ['anime_seed_id', 'search_title', 'stage', 'reason'])

    (outdir / 'animes.json').write_text(json.dumps(anime_rows, ensure_ascii=False, indent=2), encoding='utf-8')
    (outdir / 'characters.json').write_text(json.dumps(character_rows, ensure_ascii=False, indent=2), encoding='utf-8')
    (outdir / 'anime_character_links.json').write_text(json.dumps(link_rows, ensure_ascii=False, indent=2), encoding='utf-8')
    (outdir / 'summary.json').write_text(json.dumps({
        'anime_count': len(anime_rows),
        'character_count': len(character_rows),
        'anime_character_link_count': len(link_rows),
        'failure_count': len(failures),
        'main_only': bool(args.main_only),
        'source_api': 'Jikan v4'
    }, ensure_ascii=False, indent=2), encoding='utf-8')

    maybe_make_xlsx(outdir, anime_rows, character_rows, link_rows)
    print(json.dumps({
        'anime_count': len(anime_rows),
        'character_count': len(character_rows),
        'anime_character_link_count': len(link_rows),
        'failure_count': len(failures),
        'output_dir': str(outdir)
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
